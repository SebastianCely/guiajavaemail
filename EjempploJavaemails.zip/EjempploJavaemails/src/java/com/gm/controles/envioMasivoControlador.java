/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gm.controles;

import com.csvreader.CsvReader;
import javax.servlet.http.Part;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author Usuario
 */
@Named(value = "envioMasivoControlador")
@RequestScoped
public class envioMasivoControlador {

    private Part archivo;

    

    public envioMasivoControlador() {
    }
    public void subirArchivo(){
        try{
            System.out.println("ENTRO");
            System.out.println("nombre: " + this.archivo.getName());
        }catch(Exception e){
            System.out.println("No entro: " + e.getMessage());
        }
    }

    public Part getArchivo() {
        return archivo;
    }

    public void setArchivo(Part archivo) {
        this.archivo = archivo;
    }

}
